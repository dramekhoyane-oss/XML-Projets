using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Maze_Escape;

public class Bullet
{
    public Vector2 bulletPosition;
    public Vector2 bulletSpeed;
    public bool bulletIsOn;
    private Texture2D _bulletTexture;

    public Bullet(Vector2 startPoint, Vector2 direction, Texture2D bulletTexture)
    {
        bulletPosition = startPoint;
        bulletSpeed = direction * 600f; 
        bulletIsOn = true;
        _bulletTexture = bulletTexture;
    }

    public void Update(GameTime gameTime, Labyrinthe maze)
    {
        if (bulletIsOn == false)
        {
            return;
        }

        bulletPosition += bulletSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds; // delta time dependency: https://community.monogame.net/t/should-you-make-use-of-delta-time-for-framerate-independent-code/9879
        // https://community.monogame.net/t/when-to-use-gametime/15185
        
        if (bulletPosition.Y < 0 || bulletPosition.Y > 768 || bulletPosition.X < 0 || bulletPosition.X > 1280) // if the bullet is not on the screen, remove it
        {
            bulletIsOn = false;
        }

        if (maze.IsWallAt(bulletPosition))
        {
            maze.DestroyWallAt(bulletPosition);
            bulletIsOn = false;
        }
        
    } 
    public void Draw(SpriteBatch spriteBatch)
    {
        if (bulletIsOn == true)
        {
            spriteBatch.Draw(_bulletTexture, bulletPosition, Color.White); 
        }
    }
}