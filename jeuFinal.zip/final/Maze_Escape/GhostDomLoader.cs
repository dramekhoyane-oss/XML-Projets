using System.Collections.Generic;
using Microsoft.Xna.Framework;                //pour la structure Vector2
using Microsoft.Xna.Framework.Graphics;       //pour Texture2D
using System.Xml.Linq;

namespace Maze_Escape;


public static class GhostDomLoader
{
    public static List<Ghost> LoadGhosts(string path, Texture2D texture)
    {
        var ghosts = new List<Ghost>();
        XDocument doc = XDocument.Load(path);
        XNamespace ns = "http://www.univ-grenoble-alpes.fr/l3miage/jeu";

        var ghostElements = doc.Root.Element(ns + "ghosts")?.Elements(ns + "ghost");
        if (ghostElements != null)
        {
            foreach (var g in ghostElements)
            {
                int x = int.Parse(g.Attribute("x").Value);
                int y = int.Parse(g.Attribute("y").Value);
                ghosts.Add(new Ghost(new Vector2(x * 64 + 32, y * 64 + 32), texture));
            }
        }
        return ghosts;
    }
}