using System.Collections.Generic;
using System . Xml . Serialization ;
using System.IO;

namespace Maze_Escape;

public static class LabyrintheSerializer
{
    public static LabyrintheData Load(string path)
    {
        var serializer = new XmlSerializer(typeof(LabyrintheData));
        using var reader = new StreamReader(path);
        return (LabyrintheData)serializer.Deserialize(reader);
    }

    public static void Save(string path, LabyrintheData data)
    {
        var serializer = new XmlSerializer(typeof(LabyrintheData));
        using var writer = new StreamWriter(path);
        serializer.Serialize(writer, data);
    }
}