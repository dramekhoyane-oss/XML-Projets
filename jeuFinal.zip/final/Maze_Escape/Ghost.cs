using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Maze_Escape;

public class Ghost
{
    public Vector2 ghostPosition;
    public int health = 3; // le fantome a 3 vies
    public bool ghostIsOn;
    private Texture2D _ghostTexture;
    public float ghostSpeed = 250f;

    public Ghost(Vector2 startPoint, Texture2D ghostTexture)
    {
        ghostPosition = startPoint;
        _ghostTexture = ghostTexture;
        ghostIsOn = true;
    }

    public void Update(GameTime gameTime, Personnage protagoniste, Labyrinthe maze)
    {
        if (!ghostIsOn) 
        {
            return;
        }
        Vector2 ghostDirection = protagoniste.Position - ghostPosition;     // variable de la chasse du protagoniste

        if (ghostDirection != Vector2.Zero)   
        {
            ghostDirection.Normalize(); // added by the IDE and it fixes rendering bug 
            Vector2 newGhostPosition = ghostPosition + ghostDirection * ghostSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;

            Vector2 wallHit = newGhostPosition + new Vector2(32, 32);

            if (!maze.IsWallAt(wallHit))
            {
                ghostPosition = newGhostPosition;
            }
        }

        if (Vector2.Distance(ghostPosition, protagoniste.Position) < 50)  // mort du protagoniste lors du contact avec le fantome
        {
            Game1.GameOver = true;
        }
    }

    public void GhostTakesBullet()
    {
        health--;
        if (health <= 0)
        {
            ghostIsOn = false;
        }
    }
    public void Draw(SpriteBatch spriteBatch)
    {
        if (ghostIsOn)
        {
            spriteBatch.Draw(_ghostTexture, ghostPosition,Color.Red); 
        }
    }
    
    
}