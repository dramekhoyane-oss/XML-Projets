using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Maze_Escape;

public class Labyrinthe
{
    private const int SQUARE_SIZE = 64;  // png 64x64
    private const int WIDTH = 20; // 20 colonnes du labyrinthe
    private const int HEIGHT = 12; // 12 rangs du labyrinthe
    
    private int[,] _wall;   // 0 = rien; 1 = mur; 2 = sortie ; 3 = mur casssable
    private Vector2 _exitWallCentre;  // milieu du carré de sortie
    private Texture2D _wallTexture;
    public Labyrinthe(int[,] layout, Texture2D wallTexture, Vector2 exitWall)
    {
        _wall = layout;
        _exitWallCentre = exitWall;
        _wallTexture = wallTexture;
    }

    public int[,] AddWallSquares
    {
        get { return _wall; }
        set { _wall = value; } 
    }

    public Vector2 ExitWall
    {
        get { return _exitWallCentre; }
        set { _exitWallCentre = value; } 
    }
    
    public void Draw(SpriteBatch spriteBatch)   
    {
        for (int y = 0; y < HEIGHT; y++)  // axe y du labyrinthe
        {
            for (int x = 0; x < WIDTH; x++)  // axe x du labyrinthe
            {
                Vector2 squarePosition = new Vector2(x * SQUARE_SIZE, y * SQUARE_SIZE);   // squarePosition=(x * 64 + y * 64)
                int square = AddWallSquares[y, x];                     // prend l'int (0,1,2,3(type mur)) de la position donnée

                switch (square)
                {
                    case 1: // mur 
                        spriteBatch.Draw(_wallTexture, squarePosition, Color.White);
                        break;
                    case 3: // mur cassable
                        spriteBatch.Draw(_wallTexture, squarePosition, Color.Chocolate);
                        break;
                    case 2: // sortie 
                        spriteBatch.Draw(_wallTexture, squarePosition, Color.Chartreuse);
                        break;
                }
            }
        }
    }

    public bool IsWallAt(Vector2 wallPos) 
    {
        int squareX = (int)(wallPos.X / SQUARE_SIZE); // coordonnée du mur (positionX / 64 px) ex: X = 1 , Y = 2 
        int squareY = (int)(wallPos.Y / SQUARE_SIZE); // idem pour positionY

        if (squareX < 0 || squareY >= WIDTH || squareY < 0 || squareY >= HEIGHT)  // bloque le sprite de sortir des limites du labyrinthe
        {
            return true;
        }
        int square = AddWallSquares[squareY, squareX]; // (ligne, colonne) pour verifier le type de mur (0,1,2,3)
        return (square == 1 || square == 3); // seulement 1 et 3 bloquent le mouvement
    }

    public bool DestroyWallAt(Vector2 worlPos)
    {
        int squareX = (int)(worlPos.X / SQUARE_SIZE);
        int squareY = (int)(worlPos.Y / SQUARE_SIZE);

        if (squareX < 0 || squareY >= WIDTH || squareY < 0 || squareY >= HEIGHT)
        {
            return false;
        }    // meme logiqe que IsWallAt

        if (AddWallSquares[squareY, squareX] == 3) // si le mur est de type 3 (cassable), on le transforme en passage libre (type 0)
        {
            AddWallSquares[squareY, squareX] = 0;
            return true;
        }
        return false;
    }

    public bool PlayerAtExit(Vector2 playerCenter)  // verification de la distance par rapport a la sortie
    {
        return Vector2.Distance(playerCenter, _exitWallCentre) < SQUARE_SIZE * 1.0f; // le joueur doit etre a - de 64 px du centre de la sortie
    }
}