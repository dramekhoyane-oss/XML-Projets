using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Maze_Escape;

public class Personnage
{
    private Vector2 _pos;
    private float _speed;
    private float _width;  // taille du personnage
    private float _height;

    public Vector2 Position    // ce sera utilisé par Draw()
    {
        get { return _pos; }
    }

    public float Speed
    {
        get { return _speed; }
    }

    public Personnage(float startX, float startY, Texture2D spriteTexture) 
    {
        _pos = new Vector2(startX, startY);
        _width = 64;
        _height = 64;
    }

    public void Update(KeyboardState keyboard, GameTime gameTime, Labyrinthe maze)
    {
        Vector2 movement = Vector2.Zero; // vitesse initiale est 0

        if (keyboard.IsKeyDown(Keys.Down))
        {
            movement.Y += 5f;
        }

        if (keyboard.IsKeyDown(Keys.Up))
        {
            movement.Y -= 5f;
        }

        if (keyboard.IsKeyDown(Keys.Left))
        {
            movement.X -= 5f;
        }

        if (keyboard.IsKeyDown(Keys.Right))
        {
            movement.X += 5f;
        }

        if (movement != Vector2.Zero)
        { 
            Vector2 newPos = _pos + movement; // position après mouvement
            Vector2 futureCenter = newPos + new Vector2(32, 32); // pour verifier si le sprite se cogne contre un futureCentre (mur)

            if (!maze.IsWallAt(futureCenter))  // s'il n'y a pas de collision
            {
                _pos = newPos; 
            }
            
            _pos.X = MathHelper.Clamp(_pos.X, 0, 1280 - 64);  // limites de l'ecran
            _pos.Y = MathHelper.Clamp(_pos.Y, 0, 768 - 64);
        }
    }
}