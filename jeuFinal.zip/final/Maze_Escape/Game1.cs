﻿using System.Collections.Generic; // List<T>
using Microsoft.Xna.Framework;    
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Maze_Escape;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    
    // mes variables
    private Texture2D _background;
    private Texture2D _protagonisteTexture;
    private Texture2D _mur;
    private Texture2D _bulletTexture;
    private Texture2D _ghostTexture;
    
    private Personnage _protagoniste;
    private Labyrinthe _maze;
    
    private List<Bullet> _bullets;
    private List<Ghost> _ghosts;

    public static bool GameOver = false;
    private KeyboardState _previousKeyboard;  // variable de la classe KeyBoardState
    private int currentLevel = 1;
    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;

        _graphics.PreferredBackBufferWidth = 1280;  // l'ecran a des dimensions qui sont des multiples de 64
        _graphics.PreferredBackBufferHeight = 768;
        _graphics.ApplyChanges();
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        // TODO: use this.Content to load your game content here

        _background = Content.Load<Texture2D>("background");
        _protagonisteTexture = Content.Load<Texture2D>("astronautSprite");
        _mur = Content.Load<Texture2D>("border");
        _bulletTexture = Content.Load<Texture2D>("bulletTexture");
        _ghostTexture = Content.Load<Texture2D>("alien");

        _bullets = new List<Bullet>();
        _ghosts = new List<Ghost>();

        LoadLevel(1);
    }

    private void LoadLevel(int level)
    {
        currentLevel = level;

        //charge labyrinthe via sérialisation
        var data = LabyrintheSerializer.Load($"maze{level}.xml");
        
        //crée la grille int[,]
        int[,] grid = new int[data.Lignes, data.Colonnes];
        for (int y = 0; y < data.Lignes; y++)
        {
            var vals = data.Grille.Rows[y].Split(',');
            for (int x = 0; x < data.Colonnes; x++)
                grid[y, x] = int.Parse(vals[x].Trim());
        }

        //calcul centre de sortie
        Vector2 exit = new Vector2(data.SortieX * 64 + 32, data.SortieY * 64 + 32);

        // appel constructeur 
        
        _maze = new Labyrinthe(grid, _mur, exit);
        

        //anitialise le joueur selon startt
        _protagoniste = new Personnage(data.Start.X * 64 + 32, data.Start.Y * 64 + 32, _protagonisteTexture);

        //ccharge les ghosts via DOM
        _ghosts = GhostDomLoader.LoadGhosts($"maze{level}.xml", _ghostTexture);
        
        _bullets.Clear();
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
            Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        var keyboardState = Keyboard.GetState();  // verifie l'etat du clavier
        if (keyboardState.IsKeyDown(Keys.Escape))
        {
            Exit();
        }

        if (GameOver)
        {
            return;
        }
        
        if (keyboardState.IsKeyDown(Keys.Space) && _previousKeyboard.IsKeyUp(Keys.Space))  // tire une seule fois par appui de space
        {
            Vector2 bulletDirection = Vector2.Zero;
            
            if (keyboardState.IsKeyDown(Keys.Up))
            {
                bulletDirection.Y = -1;  
            }
            if (keyboardState.IsKeyDown(Keys.Down))
            {
                bulletDirection.Y = 1;
            }
            if (keyboardState.IsKeyDown(Keys.Left))
            {
                bulletDirection.X = -1;
            }
            if (keyboardState.IsKeyDown(Keys.Right))
            {
                bulletDirection.X = 1;
            }

            if (bulletDirection != Vector2.Zero)
            {
                bulletDirection.Normalize();
                _bullets.Add(new Bullet(_protagoniste.Position + new Vector2(32, 32), bulletDirection, _bulletTexture));
            }
        }
        _previousKeyboard = keyboardState;  // reset le spacebar 
        
        _protagoniste.Update(keyboardState, gameTime, _maze);
        
        for (int i = _bullets.Count - 1; i >= 0; i--)  // liste bullets
        {
            _bullets[i].Update(gameTime, _maze);   // mettre a jour la vitesse de la balle et le rapport aux murs dans le labyrinthe
            if (!_bullets[i].bulletIsOn)
            {
                _bullets.RemoveAt(i);       // enleve les balles qui ne sont plus valables
            }
        }
        
        for (int i = 0; i < _ghosts.Count; i++) 
        {
            if (_ghosts[i].ghostIsOn)
            {
                _ghosts[i].Update(gameTime, _protagoniste, _maze);        // les fantomes meurent apres 3 tirs
            }
        }
        
        for (int i = _bullets.Count - 1; i >= 0; i--)    // verification collision balle avec fantôme 
        {
            for (int j = 0; j < _ghosts.Count; j++)
            {
                if (_ghosts[j].ghostIsOn && 
                    Vector2.Distance(_bullets[i].bulletPosition, _ghosts[j].ghostPosition) < 32)
                {
                    _ghosts[j].GhostTakesBullet();
                    _bullets[i].bulletIsOn = false;
                    break;
                }
            }
        }
        
        Vector2 personnageSpawnPoint = _protagoniste.Position + new Vector2(32, 32);   
        if (_maze.PlayerAtExit(personnageSpawnPoint))
        {
            LoadLevel(currentLevel+1);
        }

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        // TODO: Add your drawing code here
        
        _spriteBatch.Begin();
        
        var screenSize = new Rectangle(0,0,GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);  // l'ecran commence de (0,0) et qui a les dimensions du constructeur; le _background est ajusté automatiquement
        _spriteBatch.Draw(_background, screenSize, Color.White);
        _maze.Draw(_spriteBatch);
        
        for (int i = 0; i < _bullets.Count; i++) // dessine les balles
        {
            _bullets[i].Draw(_spriteBatch);
        }
        
        for (int i = 0; i < _ghosts.Count; i++) // dessine les balles fantomes
        {
            _ghosts[i].Draw(_spriteBatch);
        }
        
        _spriteBatch.Draw(_protagonisteTexture, _protagoniste.Position, Color.White);
        
        Vector2 playerCenter = _protagoniste.Position + new Vector2(_protagonisteTexture.Width/2f, _protagonisteTexture.Height / 2f); // definir le centre du protagoniste au moment de son apparition
        if (_maze.PlayerAtExit(playerCenter))
        {
            
        }
        _spriteBatch.End();

        base.Draw(gameTime);
    }
}