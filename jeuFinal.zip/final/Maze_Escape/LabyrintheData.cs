using System.Collections.Generic;
using System . Xml . Serialization ;



[XmlRoot("Labyrinthe", Namespace = "http://www.univ-grenoble-alpes.fr/l3miage/jeu")]



public class LabyrintheData
{
    
    [XmlAttribute("colonnes")]
    public int Colonnes { get; set; }

    [XmlAttribute("lignes")]
    public int Lignes { get; set; }

    [XmlAttribute("sortieX")]
    public int SortieX { get; set; }

    [XmlAttribute("sortieY")]
    public int SortieY { get; set; }

    [XmlElement("grille", Namespace="http://www.univ-grenoble-alpes.fr/l3miage/jeu")]
    public GrilleData Grille { get; set; }
    
    [XmlElement("start", Namespace = "http://www.univ-grenoble-alpes.fr/l3miage/jeu")]
    public Start Start { get; set; }
}

public class GrilleData
{
    [XmlElement("row", Namespace="http://www.univ-grenoble-alpes.fr/l3miage/jeu")]
    public List<string> Rows { get; set; }
}

public class Start
{
    [XmlAttribute]
    public int X { get; set; }

    [XmlAttribute]
    public int Y { get; set; }
}
