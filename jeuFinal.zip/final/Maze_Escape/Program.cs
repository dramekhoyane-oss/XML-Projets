﻿using var game = new Maze_Escape.Game1();
game.Run();